def main():
    print("PET Processing Module")
    
if __name__ == "__main__":
    main()